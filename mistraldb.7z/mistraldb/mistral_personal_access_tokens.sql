-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: mistral
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES (1,'App\\Models\\User',4,'1661688949','0edb1eedac3ff978bc44dfb907e7d272c0b96738104cfc04483c991a74257ede','[\"*\"]',NULL,NULL,'2022-08-28 10:15:49','2022-08-28 10:15:49'),(2,'App\\Models\\User',4,'1661688958','2d1d4ac729cdbaba69916e706a86a7ed8287ccea82e5719d0a0556c8ec32cc9e','[\"*\"]',NULL,NULL,'2022-08-28 10:15:58','2022-08-28 10:15:58'),(3,'App\\Models\\User',4,'1661689053','c5bedecb63e4cd4b122ff17db44ffbc3399bf0109764c72ce7d3f28cc767ccfc','[\"*\"]',NULL,NULL,'2022-08-28 10:17:33','2022-08-28 10:17:33'),(4,'App\\Models\\User',6,'1661708164','74082762fa670475841da3217f96d3174f9ea4c147eb1ce0354455fc079b3efe','[\"*\"]',NULL,NULL,'2022-08-28 15:36:04','2022-08-28 15:36:04'),(5,'App\\Models\\User',6,'1661708174','c694780268f9e3676ee45efa0e990c2feaeac2fe90dd60f3986712b41d4f61bf','[\"*\"]',NULL,NULL,'2022-08-28 15:36:14','2022-08-28 15:36:14'),(6,'App\\Models\\User',6,'1661718294','3b39606ac740eed4007b14223fb9072849eb52f0feab3fe858a3fbcda5f6eb3e','[\"*\"]',NULL,NULL,'2022-08-28 18:24:54','2022-08-28 18:24:54'),(7,'App\\Models\\User',6,'1661718353','a9ec859f7f0a4fca5c91a52b466eb7eb2f5f3577bec0f8686c87fbddc4ca4679','[\"*\"]',NULL,NULL,'2022-08-28 18:25:53','2022-08-28 18:25:53'),(8,'App\\Models\\User',6,'1661718425','8fa05bd42725aa176bb0dfae48cb5af66b530175e590d032dc0a8708ecbf3431','[\"*\"]',NULL,NULL,'2022-08-28 18:27:05','2022-08-28 18:27:05'),(9,'App\\Models\\User',6,'1661718441','578e5b4e63016a70dc2b37855a8e595e4fbc1ef800ba100720ab39c9f78bd830','[\"*\"]',NULL,NULL,'2022-08-28 18:27:21','2022-08-28 18:27:21'),(10,'App\\Models\\User',6,'1661718477','da519e19f985210fe593febb1d6ba73a20c72899cdefa777c4b2f969a5609b22','[\"*\"]',NULL,NULL,'2022-08-28 18:27:57','2022-08-28 18:27:57'),(11,'App\\Models\\User',4,'1661718588','76de2e634eab9e8468e0bbb3474d42d4e303ee97fd052dc9e7835ced581fecc6','[\"*\"]',NULL,NULL,'2022-08-28 18:29:48','2022-08-28 18:29:48'),(12,'App\\Models\\User',15,'1661718897','6e1c85367d1690dddbf3d319689b0fe9846d44f1bf98af8e50015802c03d59a0','[\"*\"]',NULL,NULL,'2022-08-28 18:34:57','2022-08-28 18:34:57'),(13,'App\\Models\\User',6,'1661719325','bb07f196887854b52efa4dd283413c15ce4a64e9c750dc72013c9699e25f4c8a','[\"*\"]',NULL,NULL,'2022-08-28 18:42:05','2022-08-28 18:42:05'),(14,'App\\Models\\User',4,'1661721940','dd3faa10617b5a2fc41bf738d9271178884b71b14342582e2e6b7a0ccc3d9cfb','[\"*\"]',NULL,NULL,'2022-08-28 19:25:40','2022-08-28 19:25:40'),(15,'App\\Models\\User',17,'1661816572','f58b5ebbeeaf71d37b861862bde41ee7e3d258faae3692a05b4d2aca85d2b2dd','[\"*\"]',NULL,NULL,'2022-08-29 21:42:52','2022-08-29 21:42:52'),(16,'App\\Models\\User',6,'1661852237','63430638bfd770a477a0620c4cfec21a79d5fd2b136a7ffb6cc1c1936da339ca','[\"*\"]','2022-08-30 07:37:34',NULL,'2022-08-30 07:37:17','2022-08-30 07:37:34'),(17,'App\\Models\\User',5,'1661852736','840c2ba8b0e3083306f24689b8b8df8fe07ee4f640d4b5204d59ef414e44a856','[\"*\"]','2022-08-30 07:48:41',NULL,'2022-08-30 07:45:36','2022-08-30 07:48:41'),(18,'App\\Models\\User',5,'1661853105','c4a42c7def9d28b3a8bf676331514846b4c1b6226aa505288e56d8df21e9dd25','[\"*\"]','2022-08-30 08:02:11',NULL,'2022-08-30 07:51:45','2022-08-30 08:02:11');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-30 12:05:11
